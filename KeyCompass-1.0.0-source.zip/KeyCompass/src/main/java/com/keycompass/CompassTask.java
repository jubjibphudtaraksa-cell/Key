package com.keycompass;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.CompassMeta;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * ทำงานเป็นช่วงๆ: หาผู้เล่นที่ใกล้ที่สุดของเจ้าของเข็มทิศแล้วปักหมุดให้
 * ถ้าเข้าใกล้เป้าหมายภายในระยะที่กำหนด เข็มทิศทุกอันในตัวจะพังทันที
 */
public final class CompassTask extends BukkitRunnable {

    private static final Component PREFIX = Component.text("[KeyCompass] ", NamedTextColor.GOLD);

    private final KeyCompassPlugin plugin;
    private final MagicCompass magic;

    public CompassTask(KeyCompassPlugin plugin) {
        this.plugin = plugin;
        this.magic = plugin.magic();
    }

    @Override
    public void run() {
        double breakDistance = plugin.getConfig().getDouble("break-distance", 50.0);
        double breakSquared = breakDistance * breakDistance;

        for (Player holder : Bukkit.getOnlinePlayers()) {
            if (!hasMagicCompass(holder.getInventory())) {
                continue;
            }

            Player nearest = findNearest(holder);

            if (nearest != null
                    && holder.getLocation().distanceSquared(nearest.getLocation()) <= breakSquared) {
                breakCompasses(holder, breakDistance);
                continue;
            }

            pointTo(holder, nearest);
            showActionBar(holder, nearest);
        }
    }

    private boolean hasMagicCompass(PlayerInventory inv) {
        for (int i = 0; i < inv.getSize(); i++) {
            if (magic.isMagic(inv.getItem(i))) {
                return true;
            }
        }
        return false;
    }

    /** ผู้เล่นอื่นที่ใกล้ที่สุดในโลกเดียวกัน (ไม่นับ spectator) */
    private Player findNearest(Player holder) {
        Location from = holder.getLocation();
        Player best = null;
        double bestSquared = Double.MAX_VALUE;

        for (Player other : Bukkit.getOnlinePlayers()) {
            if (other.equals(holder) || other.isDead() || other.getGameMode() == GameMode.SPECTATOR) {
                continue;
            }
            if (!other.getWorld().equals(holder.getWorld())) {
                continue;
            }
            double d = from.distanceSquared(other.getLocation());
            if (d < bestSquared) {
                bestSquared = d;
                best = other;
            }
        }
        return best;
    }

    private void pointTo(Player holder, Player target) {
        PlayerInventory inv = holder.getInventory();
        Location targetLoc = target == null ? null : target.getLocation();

        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack item = inv.getItem(i);
            if (!magic.isMagic(item)) {
                continue;
            }
            CompassMeta meta = (CompassMeta) item.getItemMeta();
            Location current = meta.getLodestone();

            if (targetLoc == null) {
                if (current == null) {
                    continue;
                }
                meta.setLodestone(null);
            } else {
                // อัปเดตเฉพาะเมื่อเป้าหมายขยับเกิน 2 บล็อก เพื่อไม่ให้ไอเท็มในมือกระตุก
                if (current != null
                        && current.getWorld() != null
                        && current.getWorld().equals(targetLoc.getWorld())
                        && current.distanceSquared(targetLoc) < 4.0
                        && !meta.isLodestoneTracked()) {
                    continue;
                }
                meta.setLodestone(targetLoc);
                meta.setLodestoneTracked(false);
            }
            item.setItemMeta(meta);
            inv.setItem(i, item);
        }
    }

    private void showActionBar(Player holder, Player target) {
        PlayerInventory inv = holder.getInventory();
        if (!magic.isMagic(inv.getItemInMainHand()) && !magic.isMagic(inv.getItemInOffHand())) {
            return;
        }
        if (target == null) {
            holder.sendActionBar(Component.text("ไม่พบผู้เล่นคนอื่นในโลกนี้", NamedTextColor.GRAY));
            return;
        }
        long distance = Math.round(holder.getLocation().distance(target.getLocation()));
        holder.sendActionBar(Component.text("เป้าหมาย: ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text(target.getName(), NamedTextColor.WHITE))
                .append(Component.text("  |  ห่าง " + distance + " บล็อก", NamedTextColor.YELLOW)));
    }

    private void breakCompasses(Player holder, double breakDistance) {
        PlayerInventory inv = holder.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            if (magic.isMagic(inv.getItem(i))) {
                inv.setItem(i, null);
            }
        }
        holder.playSound(holder.getLocation(), "entity.item.break", SoundCategory.PLAYERS, 1.0f, 1.0f);
        holder.sendMessage(PREFIX.append(Component.text(
                "เข็มทิศวิเศษพังแล้ว! คุณเข้าใกล้ผู้เล่นคนอื่นภายใน " + (int) breakDistance + " บล็อก",
                NamedTextColor.RED)));
    }
}
