package com.keycompass;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.List;

public final class KeyCompassPlugin extends JavaPlugin {

    private KeyManager keyManager;
    private MagicCompass magicCompass;
    private BukkitTask compassTask;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        keyManager = new KeyManager(this);
        keyManager.load();
        magicCompass = new MagicCompass(this);

        KeyCommands commands = new KeyCommands(this);
        for (String name : List.of("key", "addkey", "dekey", "deakey", "showkey")) {
            PluginCommand command = getCommand(name);
            if (command != null) {
                command.setExecutor(commands);
                command.setTabCompleter(commands);
            }
        }

        long interval = Math.max(1L, getConfig().getLong("update-interval-ticks", 10L));
        compassTask = new CompassTask(this).runTaskTimer(this, interval, interval);

        getLogger().info("KeyCompass enabled, loaded " + keyManager.all().size() + " key(s).");
    }

    @Override
    public void onDisable() {
        if (compassTask != null) {
            compassTask.cancel();
        }
        if (keyManager != null) {
            keyManager.save();
        }
    }

    public KeyManager keys() {
        return keyManager;
    }

    public MagicCompass magic() {
        return magicCompass;
    }
}
